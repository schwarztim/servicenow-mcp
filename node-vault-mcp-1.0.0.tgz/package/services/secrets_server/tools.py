"""secrets_server/tools.py — 8 vault_* MCP tools (metadata only, never values).

Public functions with docstrings become MCP tools via FastMCP add_tool discovery
in node-vault-mcp.py. Each delegates to vault_secrets.core.

No vault_set or vault_get tools exist by design — secret values never appear in
MCP tool interfaces.
"""
from __future__ import annotations

from vault_secrets import core as _core


# ── VAULT METADATA (4 tools — NEVER expose secret values) ────────────────────


def vault_list(scope: str = "") -> str:
    """List vault entries (metadata only — names, expiry, sources). Never returns secret values.

    Args:
        scope: Optional prefix filter (e.g., "pref-" for preferences).

    Returns JSON with count and entries array.
    """
    return _core.vault_list(scope=scope)


def vault_audit(scope: str = "") -> str:
    """Audit vault entries for expiry — surfaces expired or expiring-within-7-days entries.

    Args:
        scope: Optional prefix filter (e.g., "pref-").

    Returns JSON with warnings_count and warnings array.
    """
    return _core.vault_audit(scope=scope)


def vault_status(service: str) -> str:
    """Check whether a vault entry exists and its metadata. Never returns the value.

    Args:
        service: Service/key name to check (e.g., "synman-github-pat").

    Returns JSON with exists, has_value, expiry, and source.
    """
    return _core.vault_status(service=service)


def vault_providers() -> str:
    """List available source providers (op://, keychain://, gh://, env://).

    Providers are loaded dynamically from vault_secrets/providers/*.py.

    Returns JSON with count and providers array (scheme, description, available).
    """
    return _core.vault_providers()


# ── VAULT WRITE (4 tools — operator approval required) ───────────────────────


def vault_update(
    service: str,
    notes: str = "",
    expires: str = "",
    rotation: str = "",
    confirmed: bool = False,
) -> str:
    """Update metadata on a vault entry. Never touches the secret value.

    Operator approval required — present the consequence before executing, even if the operator already asked for this action.

    Args:
        service: Service/key name to update.
        notes: Updated notes (empty = keep existing).
        expires: Expiry date YYYY-MM-DD (empty = keep existing).
        rotation: Rotation interval e.g. "90d" (empty = keep existing).
        confirmed: Set to True after user approves.
    """
    return _core.vault_update(
        service=service,
        notes=notes,
        expires=expires,
        rotation=rotation,
        confirmed=confirmed,
    )


def vault_delete(service: str, confirmed: bool = False) -> str:
    """Delete a vault entry permanently. Irreversible.

    Operator approval required — present the consequence before executing, even if the operator already asked for this action.

    Args:
        service: Service/key name to delete.
        confirmed: Set to True after user approves.
    """
    return _core.vault_delete(service=service, confirmed=confirmed)


def vault_register(
    service: str,
    source: str,
    rotation: str = "",
    notes: str = "",
    confirmed: bool = False,
) -> str:
    """Register an external source for a vault entry — stub, first get triggers fetch.

    Operator approval required — present the consequence before executing, even if the operator already asked for this action.

    Args:
        service: Service/key name to register.
        source: Source URI (op://vault/item/field, keychain://svc/acct, gh://auth/token, env://VAR).
        rotation: Rotation interval e.g. "90d" (empty = default).
        notes: Human-readable note (empty = none).
        confirmed: Set to True after user approves.
    """
    return _core.vault_register(
        service=service,
        source=source,
        rotation=rotation,
        notes=notes,
        confirmed=confirmed,
    )


def vault_refresh(service: str, confirmed: bool = False) -> str:
    """Re-fetch a vault entry from its registered external source. Value never returned.

    Operator approval required — present the consequence before executing, even if the operator already asked for this action.

    Args:
        service: Service/key name to refresh.
        confirmed: Set to True after user approves.
    """
    return _core.vault_refresh(service=service, confirmed=confirmed)
