#!/usr/bin/env python3
"""node-vault-mcp — stdio MCP server for vault & secrets management.

AES-256-GCM encrypted vault at ~/.claude/secrets.vault. Three access surfaces
backed by vault_secrets.core:
  (a) Native Python import   from vault_secrets.core import vault_*, get_pref_value, get_secret_value
  (b) Bash CLI               services/secrets.py
  (c) MCP stdio (this file)  mcp__node-vault-mcp__vault_*

No HTTP, no daemon, no listening port. All vault operations are pure in-process
Python — no subprocess/threading/fork (security-peer lifecycle invariant).

Sets ISAAC_MCP_NO_VALUE_READ=1 at startup so vault_secrets.core value-readers
raise if accidentally imported in this process.
"""

import logging
import os
import sys
from pathlib import Path

# Ensure services/ is on sys.path so the local secrets_server / vault_secrets
# packages are importable when run from the install location. Mirrors the
# shadowing-prevention pattern in isaac-mcp.py — the moved secrets.py would
# shadow the Python stdlib `secrets` module if services/ landed early on
# sys.path. The package was renamed to vault_secrets specifically to avoid
# this collision; the bash CLI script services/secrets.py is path-only and
# does not appear on sys.path as an importable name.
_SERVICES_DIR = str(Path(__file__).resolve().parent)
_to_remove = []
for _i, _p in enumerate(sys.path):
    _resolved = str(Path(_p).resolve()) if _p else str(Path.cwd().resolve())
    if _resolved == _SERVICES_DIR:
        _to_remove.append(_p)
for _p in _to_remove:
    sys.path.remove(_p)
sys.path.append(_SERVICES_DIR)

# Defense-in-depth: signal to in-process value-readers (get_pref_value /
# get_secret_value) that they must refuse to resolve from this MCP-server
# process. They check this env var and raise on read.
os.environ["ISAAC_MCP_NO_VALUE_READ"] = "1"

from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=os.environ.get("NODE_VAULT_MCP_LOG_LEVEL", "WARNING"))
log = logging.getLogger("node-vault-mcp")

mcp = FastMCP("node-vault-mcp")

# Tool registration: discover public functions in secrets_server.tools and
# register each as an MCP tool via FastMCP's add_tool. Mirrors the pattern in
# isaac-mcp.py — keeps tools.py free of FastMCP dependencies and avoids the
# circular import that @mcp.tool decorators would impose.
try:
    from secrets_server import tools as _tools_mod
    _registered = 0
    for _name in dir(_tools_mod):
        if _name.startswith("_"):
            continue
        _fn = getattr(_tools_mod, _name)
        if (
            callable(_fn)
            and hasattr(_fn, "__module__")
            and _fn.__module__ == _tools_mod.__name__
            and hasattr(_fn, "__doc__")
            and _fn.__doc__
        ):
            mcp.add_tool(_fn)
            _registered += 1
    log.debug("secrets_server.tools registered %d vault_* tools", _registered)
except ImportError:
    # Skeleton state (batch-1 only): tool module not yet present. Stdio server
    # remains runnable so install-hooks bootstrap can validate the entrypoint
    # before batch-2 lands the implementation.
    log.debug("secrets_server.tools not yet present — running with no tools (skeleton state)")


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
