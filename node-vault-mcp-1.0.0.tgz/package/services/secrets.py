#!/usr/bin/env python3
"""secrets.py — platform-agnostic encrypted vault for workspace credentials.

Vault: AES-256-GCM with CSPRNG-generated 256-bit key, stored at
~/.claude/secrets.vault. Key resolution order:
  1. SECRETS_KEY environment variable (base64-encoded, for CI/containers)
  2. ~/.claude/master.key file (mode 0400 — preferred, no interactive prompts)
  3. OS keychain via `keyring` (fallback)
  4. Fail closed (no default — first use auto-generates into keychain)

Usage:
  secrets.py set      <service> [--expires YYYY-MM-DD] [--rotation INTERVAL]
                      [--notes TEXT] [--value VALUE] [--source URI]
  secrets.py get      <service>        # prints secret to stdout (no newline)
                                       # cache-through: fetches from source on miss/expiry
  secrets.py delete   <service>
  secrets.py update   <service> [--expires YYYY-MM-DD] [--rotation INTERVAL] [--notes TEXT]
  secrets.py register <service> --source URI [--rotation INTERVAL] [--notes TEXT]
                                       # stub entry — first get triggers cache-through
  secrets.py refresh  <service>        # force re-fetch from registered external source
  secrets.py list     [--scope PREFIX]
  secrets.py audit    [--scope PREFIX]  # graded expiry warnings
  secrets.py migrate  <service> [--account EMAIL]  # import from macOS Keychain
  secrets.py rekey                     # re-encrypt vault with new CSPRNG key

Source URI schemes (for --source / register) — loaded dynamically from
services/providers/*.py. To add a provider: create a .py file with SCHEME,
DESCRIPTION, DETECT_CMD constants and a fetch(uri) function.
  op://vault/item/field       1Password CLI (op read)
  keychain://service/account  macOS Keychain (security find-generic-password)
  gh://auth/token             GitHub CLI (gh auth token)
  env://VAR_NAME              Environment variable

Rotation interval format: Nd (days), Nmo (months), Ny (years) — e.g. 90d, 6mo, 1y
On renewal, if rotation_interval is set, expires is auto-calculated as today + interval.

Exit codes:
  0  success
  1  secret not found
  2  vault I/O or decryption error
"""

import argparse
import base64
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import stat
import subprocess
import sys
from datetime import date, datetime, timezone
from pathlib import Path

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    sys.exit("cryptography package required: pip install cryptography")

# Keyring import — graceful fallback
try:
    import keyring
    _HAS_KEYRING = True
except ImportError:
    _HAS_KEYRING = False

VAULT_PATH = Path.home() / ".claude" / "secrets.vault"
MASTER_KEY_FILE = Path.home() / ".claude" / "master.key"
KEYCHAIN_SERVICE = "claude-secrets-vault"
KEYCHAIN_ACCOUNT = "master-key"
ALGO = "AES-256-GCM"
KEY_LEN = 32
NONCE_LEN = 12

# Legacy v1 constants (for migration only)
_V1_ITERATIONS = 600_000
_V1_SALT_LEN = 16
_V1_PASSPHRASE_FILE = Path.home() / ".claude" / "secrets.passphrase"

# Expiry thresholds (days) → (emoji, label, is_critical)
SEVERITY = [
    (0,  "🚨", "EXPIRED",  True),
    (15, "💀", "CRITICAL", True),
    (30, "🔴", "Urgent",   False),
    (60, "🟠", "Warning",  False),
    (90, "🟡", "Notice",   False),
]


# ── Key cache + keyring timeout helpers ───────────────────────────────────

_cached_key: bytes | None = None
_KEYCHAIN_LOCK = Path.home() / ".claude" / ".keychain.lock"


def _acquire_keychain_lock(timeout: int = 5) -> "int | None":
    """Acquire a cross-process lockfile for keychain access. Returns fd or None."""
    import fcntl, errno, time
    try:
        _KEYCHAIN_LOCK.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(_KEYCHAIN_LOCK), os.O_CREAT | os.O_WRONLY, 0o600)
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return fd
            except OSError as e:
                if e.errno not in (errno.EACCES, errno.EAGAIN):
                    raise
                if time.monotonic() >= deadline:
                    os.close(fd)
                    return None
                time.sleep(0.1)
    except Exception:
        return None


def _release_keychain_lock(fd: int) -> None:
    """Release cross-process keychain lockfile."""
    import fcntl
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)
    except Exception:
        pass


def _keyring_get_with_timeout(service: str, account: str, timeout: int = 5) -> str | None:
    """keyring.get_password with cross-process lock + timeout to prevent contention."""
    fd = _acquire_keychain_lock(timeout)
    if fd is None:
        print(f"⚠️  Keychain lock acquisition timed out ({timeout}s) — skipping", file=sys.stderr)
        return None
    try:
        import threading
        result = [None]
        exc = [None]
        def _fetch():
            try:
                result[0] = keyring.get_password(service, account)
            except Exception as e:
                exc[0] = e
        t = threading.Thread(target=_fetch, daemon=True)
        t.start()
        t.join(timeout=timeout)
        if t.is_alive():
            print(f"⚠️  Keychain access timed out ({timeout}s) — skipping", file=sys.stderr)
            return None
        if exc[0] is not None:
            raise exc[0]
        return result[0]
    finally:
        _release_keychain_lock(fd)


def _keyring_set_with_timeout(service: str, account: str, value: str, timeout: int = 5) -> bool:
    """keyring.set_password with cross-process lock + timeout."""
    fd = _acquire_keychain_lock(timeout)
    if fd is None:
        print(f"⚠️  Keychain lock acquisition timed out ({timeout}s)", file=sys.stderr)
        return False
    try:
        import threading
        exc = [None]
        done = [False]
        def _store():
            try:
                keyring.set_password(service, account, value)
                done[0] = True
            except Exception as e:
                exc[0] = e
        t = threading.Thread(target=_store, daemon=True)
        t.start()
        t.join(timeout=timeout)
        if t.is_alive():
            print(f"⚠️  Keychain write timed out ({timeout}s)", file=sys.stderr)
            return False
        if exc[0] is not None:
            raise exc[0]
        return done[0]
    finally:
        _release_keychain_lock(fd)


# ── Key management ─────────────────────────────────────────────────────────

def _get_key() -> bytes:
    """Resolve the vault master key. Resolution order:
    1. SECRETS_KEY env var (base64-encoded)
    2. ~/.claude/master.key file (mode 0400)
    3. OS keychain via keyring
    4. First use: generate and store in keychain
    5. Fail closed
    """
    global _cached_key
    if _cached_key is not None:
        return _cached_key

    # 1. Environment variable
    if env_key := os.environ.get("SECRETS_KEY"):
        try:
            key = base64.b64decode(env_key)
            if len(key) != KEY_LEN:
                print(f"❌ SECRETS_KEY must decode to {KEY_LEN} bytes, got {len(key)}", file=sys.stderr)
                sys.exit(2)
            _cached_key = key
            return key
        except Exception as e:
            print(f"❌ SECRETS_KEY is not valid base64: {e}", file=sys.stderr)
            sys.exit(2)

    # 2. File (preferred — no interactive prompts)
    if MASTER_KEY_FILE.exists():
        mode = MASTER_KEY_FILE.stat().st_mode
        if mode & (stat.S_IRGRP | stat.S_IROTH):
            print("⚠️  master.key is group/world readable — fix: chmod 400", file=sys.stderr)
        key = MASTER_KEY_FILE.read_bytes()
        if len(key) != KEY_LEN:
            print(f"❌ master.key must be exactly {KEY_LEN} bytes, got {len(key)}", file=sys.stderr)
            sys.exit(2)
        _cached_key = key
        return key

    # 3. OS keychain (with timeout to prevent PTY exhaustion under contention)
    if _HAS_KEYRING:
        try:
            stored = _keyring_get_with_timeout(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT)
            if stored is not None:
                key = base64.b64decode(stored)
                _cached_key = key
                return key
        except Exception:
            pass  # Keychain unavailable — fall through

    # 4. First use — generate and store
    if _HAS_KEYRING:
        try:
            key = os.urandom(KEY_LEN)
            if _keyring_set_with_timeout(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT, base64.b64encode(key).decode()):
                print("🔑 Generated new vault master key and stored in OS keychain.", file=sys.stderr)
                _cached_key = key
                return key
        except Exception as e:
            print(f"⚠️  Could not store key in keychain: {e}", file=sys.stderr)

    # 5. Fail closed
    print("❌ No vault master key found. Set up with one of:", file=sys.stderr)
    print("   • Install keyring: pip install keyring (auto-generates on first use)", file=sys.stderr)
    print("   • Set SECRETS_KEY env var (base64-encoded 32-byte key)", file=sys.stderr)
    print(f"   • Create {MASTER_KEY_FILE} (32 raw bytes, chmod 0400)", file=sys.stderr)
    sys.exit(2)


# ── Legacy v1 passphrase support (migration only) ─────────────────────────

def _get_v1_passphrase() -> bytes:
    """Resolve passphrase using the old v1 chain. Used only for migration."""
    if val := os.environ.get("SECRETS_PASSPHRASE"):
        return val.encode()
    if _V1_PASSPHRASE_FILE.exists():
        return _V1_PASSPHRASE_FILE.read_bytes().strip()
    return b"changeit"


def _derive_v1_key(passphrase: bytes, salt: bytes) -> bytes:
    """PBKDF2 key derivation — v1 only."""
    return hashlib.pbkdf2_hmac("sha256", passphrase, salt, _V1_ITERATIONS, dklen=KEY_LEN)


def _decrypt_v1_vault(raw: dict) -> dict:
    """Decrypt a v1 vault using the old passphrase chain. Returns entries dict."""
    passphrase = _get_v1_passphrase()
    salt = base64.b64decode(raw["meta"]["salt"])
    key = _derive_v1_key(passphrase, salt)
    aesgcm = AESGCM(key)
    entries = {}
    for service, enc in raw.get("entries", {}).items():
        nonce = base64.b64decode(enc["nonce"])
        ct = base64.b64decode(enc["ciphertext"])
        plain = aesgcm.decrypt(nonce, ct, None)
        entries[service] = json.loads(plain)
    return entries


# ── Vault I/O ────────────────────────────────────────────────────────────

def _load_vault_raw() -> dict:
    if not VAULT_PATH.exists():
        return {}
    try:
        return json.loads(VAULT_PATH.read_text())
    except Exception as e:
        print(f"Failed to read vault: {e}", file=sys.stderr)
        sys.exit(2)


def _save_vault_raw(data: dict) -> None:
    VAULT_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Cross-process write serialization via flock on a sibling lock file.
    # Held for the entire write phase (write tmp + fsync + rename + fsync dir).
    # Does NOT serialize read-modify-write across processes — two `secrets.py
    # set` invocations can still race on the modify phase and lose one
    # writer's content. Corruption (interleaved bytes) IS prevented by this
    # lock plus the unique temp path. JS-side lock is in-process only (see
    # lib/vault-store.ts); a Python writer + a JS writer overlapping is not
    # serialized — flag in commit message if that scenario matters.
    lock_path = VAULT_PATH.with_suffix(".vault.lock")
    with open(lock_path, "w") as lockf:
        fcntl.flock(lockf.fileno(), fcntl.LOCK_EX)
        tmp = VAULT_PATH.with_suffix(f".vault.tmp.{os.getpid()}.{os.urandom(6).hex()}")
        # fsync(tmp) BEFORE rename: payload bytes durable before rename commits.
        with open(tmp, "w") as f:
            f.write(json.dumps(data, indent=2))
            f.flush()
            os.fsync(f.fileno())
        tmp.chmod(0o600)
        tmp.rename(VAULT_PATH)
        # fsync(parent dir) AFTER rename: rename entry itself durable.
        dir_fd = os.open(str(VAULT_PATH.parent), os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
        # Lock released on lockf close (with-block exit).


def _decrypt_vault(key: bytes) -> dict:
    """Returns entries dict. Handles v1→v2 auto-migration."""
    raw = _load_vault_raw()
    if not raw:
        return {}

    version = raw.get("meta", {}).get("version", "1")

    # v1 vault — auto-migrate
    if version == "1":
        try:
            entries = _decrypt_v1_vault(raw)
        except Exception as e:
            print(f"v1 vault decryption failed: {e}", file=sys.stderr)
            print("If you changed your passphrase, set SECRETS_PASSPHRASE env var for migration.", file=sys.stderr)
            sys.exit(2)
        # Re-encrypt as v2
        _encrypt_vault(entries, key)
        print(f"🔄 Auto-migrated vault from v1 (PBKDF2) to v2 (keychain) — {len(entries)} entries.", file=sys.stderr)
        return entries

    # v2 vault — direct key
    try:
        aesgcm = AESGCM(key)
        entries = {}
        for service, enc in raw.get("entries", {}).items():
            nonce = base64.b64decode(enc["nonce"])
            ct = base64.b64decode(enc["ciphertext"])
            aad = service.encode()
            plain = aesgcm.decrypt(nonce, ct, aad)
            entries[service] = json.loads(plain)
        return entries
    except Exception as e:
        print(f"Vault decryption failed: {e}", file=sys.stderr)
        sys.exit(2)


def _encrypt_vault(entries: dict, key: bytes) -> None:
    aesgcm = AESGCM(key)
    enc_entries = {}
    for service, entry in entries.items():
        nonce = os.urandom(NONCE_LEN)
        plain = json.dumps(entry).encode()
        aad = service.encode()
        ct = aesgcm.encrypt(nonce, plain, aad)
        enc_entries[service] = {
            "nonce": base64.b64encode(nonce).decode(),
            "ciphertext": base64.b64encode(ct).decode(),
        }
    raw = {
        "meta": {
            "version": "2",
            "algo": ALGO,
            "key_source": _detect_key_source(),
        },
        "entries": enc_entries,
    }
    _save_vault_raw(raw)


def _detect_key_source() -> str:
    """Detect which key source is active for metadata."""
    if os.environ.get("SECRETS_KEY"):
        return "env"
    if _HAS_KEYRING:
        try:
            if _keyring_get_with_timeout(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT) is not None:
                return "keychain"
        except Exception:
            pass
    if MASTER_KEY_FILE.exists():
        return "file"
    return "unknown"


# ── Expiry helpers ───────────────────────────────────────────────────────

def _days_until(expires_str: str) -> int | None:
    if not expires_str or expires_str == "—":
        return None
    try:
        exp = date.fromisoformat(expires_str)
        return (exp - date.today()).days
    except ValueError:
        return None


def _parse_rotation(interval: str) -> int | None:
    """Convert rotation interval string to days. Returns None if unparseable."""
    if not interval or interval == "—":
        return None
    interval = interval.strip().lower()
    try:
        if interval.endswith("mo"):
            return int(interval[:-2]) * 30
        if interval.endswith("y"):
            return int(interval[:-1]) * 365
        if interval.endswith("d"):
            return int(interval[:-1])
        return int(interval)  # bare integer treated as days
    except ValueError:
        return None


def _expiry_from_rotation(rotation: str) -> str | None:
    """Calculate next expiry date from rotation interval string."""
    days = _parse_rotation(rotation)
    if days is None:
        return None
    from datetime import timedelta
    return (date.today() + timedelta(days=days)).isoformat()


def _prompt_intake(service: str, existing: dict | None = None) -> tuple[str, str, str]:
    """Interactively prompt for expiry date, rotation interval, notes.
    Returns (expires, rotation_interval, notes). Called only when stdin is a TTY."""
    print(f"\n📋 Credential intake for '{service}'", file=sys.stderr)

    # Expiry date
    default_exp = existing.get("expires", "") if existing else ""
    prompt_exp = f"  Expiry date (YYYY-MM-DD{', Enter to keep ' + default_exp if default_exp and default_exp != '—' else ', Enter if unknown'}): "
    expires_raw = input(prompt_exp).strip()
    if not expires_raw and default_exp and default_exp != "—":
        expires_raw = default_exp

    # Rotation interval
    default_rot = existing.get("rotation_interval", "") if existing else ""
    prompt_rot = f"  Rotation interval (e.g. 90d, 6mo, 1y{', Enter to keep ' + default_rot if default_rot and default_rot != '—' else ', Enter if unknown'}): "
    rotation_raw = input(prompt_rot).strip()
    if not rotation_raw and default_rot and default_rot != "—":
        rotation_raw = default_rot

    # Notes
    default_notes = existing.get("notes", "") if existing else ""
    prompt_notes = f"  Notes{' (Enter to keep current)' if default_notes else ' (Enter to skip)'}: "
    notes_raw = input(prompt_notes).strip()
    if not notes_raw and default_notes:
        notes_raw = default_notes

    # If expiry not given but rotation is, auto-calculate
    if not expires_raw and rotation_raw:
        auto = _expiry_from_rotation(rotation_raw)
        if auto:
            expires_raw = auto
            print(f"  → Expiry auto-calculated from interval: {expires_raw}", file=sys.stderr)

    if not expires_raw:
        expires_raw = "—"
        if "expiry: unknown" not in notes_raw:
            notes_raw = (notes_raw + " | expiry: unknown — confirm rotation policy").strip(" |")

    return expires_raw or "—", rotation_raw or "—", notes_raw


def _severity(days: int) -> tuple[str, str, bool]:
    """Returns (emoji, label, is_critical)."""
    if days <= 0:
        return "🚨", "EXPIRED", True
    if days < 15:
        return "💀", "CRITICAL", True
    if days < 30:
        return "🔴", "Urgent", False
    if days < 60:
        return "🟠", "Warning", False
    if days < 90:
        return "🟡", "Notice", False
    return "ℹ️ ", "FYI", False


def _print_critical_block(service: str, days: int, expires: str) -> None:
    if days <= 0:
        msg = f"💀 CRITICAL — '{service}' EXPIRED on {expires}"
    else:
        msg = f"💀 CRITICAL — '{service}' expires in {days} day{'s' if days != 1 else ''} ({expires})"
    width = max(len(msg) + 4, 66)
    bar = "═" * (width - 2)
    pad = " " * (width - len(msg) - 3)
    renew = f"  Renew: secrets.py set {service} --expires YYYY-MM-DD"
    rpad = " " * max(0, width - len(renew) - 3)
    print(f"\n╔{bar}╗", file=sys.stderr)
    print(f"║ {msg}{pad}║", file=sys.stderr)
    print(f"║{renew}{rpad}║", file=sys.stderr)
    print(f"╚{bar}╝\n", file=sys.stderr)


# ── External source providers (dynamic plugin loading) ────────────────────

_PROVIDERS_DIR = Path(__file__).resolve().parent / "vault_secrets" / "providers"
_provider_cache: dict[str, tuple] | None = None


def _load_providers() -> dict[str, tuple]:
    """Discover and import provider modules from services/providers/*.py.
    Returns: {scheme: (detect_fn, fetch_fn)}"""
    providers: dict[str, tuple] = {}
    if not _PROVIDERS_DIR.is_dir():
        return providers
    for f in sorted(_PROVIDERS_DIR.glob("*.py")):
        if f.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"providers.{f.stem}", f)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        except Exception as e:
            print(f"⚠️  Failed to load provider {f.name}: {e}", file=sys.stderr)
            continue
        scheme = getattr(mod, "SCHEME", f.stem)
        detect_cmd = getattr(mod, "DETECT_CMD", None)
        fetch_fn = getattr(mod, "fetch", None)
        if fetch_fn is None:
            print(f"⚠️  Provider {f.name} has no fetch() function, skipping", file=sys.stderr)
            continue
        detect_fn = (lambda cmd=detect_cmd: shutil.which(cmd) is not None) if detect_cmd else (lambda: True)
        providers[scheme] = (detect_fn, fetch_fn)
    return providers


def _get_providers() -> dict[str, tuple]:
    """Lazy-load and cache provider registry."""
    global _provider_cache
    if _provider_cache is None:
        _provider_cache = _load_providers()
    return _provider_cache


def _fetch_from_source(source: str) -> str | None:
    """Fetch a secret value from an external source URI.
    Returns the value string, or None if fetch failed or provider unavailable."""
    scheme = source.split("://", 1)[0] if "://" in source else None
    providers = _get_providers()
    if scheme is None or scheme not in providers:
        print(f"⚠️  Unknown source scheme: {source}", file=sys.stderr)
        return None
    detect_fn, fetch_fn = providers[scheme]
    if not detect_fn():
        print(f"⚠️  Provider not available for scheme '{scheme}://'", file=sys.stderr)
        return None
    return fetch_fn(source)


# ── Commands ─────────────────────────────────────────────────────────────

def cmd_get(args) -> None:
    key = _get_key()
    entries = _decrypt_vault(key)
    entry = entries.get(args.service)
    if entry is None:
        print(f"Secret not found: '{args.service}'", file=sys.stderr)
        sys.exit(1)

    has_value = "value" in entry and entry["value"]
    source = entry.get("source")

    if has_value:
        # Check expiry — if expired and has source, try refresh
        expires = entry.get("expires", "—")
        days = _days_until(expires)
        if days is not None and days <= 0 and source:
            fresh = _fetch_from_source(source)
            if fresh is not None:
                # Refresh succeeded — update vault
                rotation = entry.get("rotation_interval", "—")
                new_expires = _expiry_from_rotation(rotation) if rotation and rotation != "—" else expires
                entry["value"] = fresh
                entry["expires"] = new_expires or expires
                entry["updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
                _encrypt_vault(entries, key)
                print(f"🔄 Refreshed from {source.split('://')[0]}:// source", file=sys.stderr)
            else:
                # Refresh failed — return cached (expired) value with warning
                print(f"⚠️  Returning expired cached value (refresh from source failed)", file=sys.stderr)
        sys.stdout.write(entry["value"])
    elif source:
        # Stub entry — first-time fetch from source
        fresh = _fetch_from_source(source)
        if fresh is None:
            print(f"Failed to fetch '{args.service}' from source: {source}", file=sys.stderr)
            sys.exit(1)
        # Cache in vault
        rotation = entry.get("rotation_interval", "—")
        entry["value"] = fresh
        entry["expires"] = _expiry_from_rotation(rotation) if rotation and rotation != "—" else "—"
        entry["updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        _encrypt_vault(entries, key)
        print(f"✅ Cached from {source.split('://')[0]}:// source", file=sys.stderr)
        sys.stdout.write(entry["value"])
    else:
        print(f"Secret has no value and no source: '{args.service}'", file=sys.stderr)
        sys.exit(1)


def cmd_set(args) -> None:
    if args.value is not None:
        value = args.value
    else:
        if sys.stdin.isatty():
            import getpass
            value = getpass.getpass(f"Value for '{args.service}': ")
        else:
            value = sys.stdin.read().rstrip("\n")

    key = _get_key()
    entries = _decrypt_vault(key)
    existing = entries.get(args.service)

    # Warn if overwriting an existing entry
    if existing:
        print(f"⚠  '{args.service}' already exists — set will OVERWRITE the stored value.", file=sys.stderr)
        print(f"   Use 'update' to change only metadata (notes, expiry, rotation).", file=sys.stderr)
        if sys.stdin.isatty():
            confirm = input("   Continue? [y/N]: ").strip().lower()
            if confirm not in ("y", "yes"):
                print("Aborted.", file=sys.stderr)
                sys.exit(1)

    # Auto-calculate expiry from rotation interval if renewing an existing entry
    expires = args.expires
    rotation = getattr(args, "rotation", None) or (existing.get("rotation_interval") if existing else None)
    notes = args.notes

    # Determine if any metadata flag was explicitly provided on the CLI.
    # If ANY flag is present, treat as non-interactive (use defaults for the rest).
    # Only prompt interactively when NO metadata flags were given at all.
    any_metadata_flag = args.expires is not None or getattr(args, "rotation", None) is not None or args.notes is not None

    if sys.stdin.isatty() and not any_metadata_flag and (expires is None or rotation is None):
        # Interactive intake: no CLI metadata flags, prompt for all fields
        prompted_expires, prompted_rotation, prompted_notes = _prompt_intake(args.service, existing)
        if expires is None:
            expires = prompted_expires
        if rotation is None:
            rotation = prompted_rotation
        if notes is None:
            notes = prompted_notes
    else:
        # Non-interactive: auto-calculate expiry from rotation if not explicitly given
        if expires is None and rotation:
            auto = _expiry_from_rotation(rotation)
            if auto:
                expires = auto
                print(f"→ Expiry auto-calculated from rotation interval: {expires}", file=sys.stderr)

    # Preserve or set source
    source = getattr(args, "source", None)
    if source is None and existing:
        source = existing.get("source")

    new_entry = {
        "value": value,
        "expires": expires or "—",
        "rotation_interval": rotation or "—",
        "notes": notes or "",
        "updated": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
    }
    if source:
        new_entry["source"] = source
    entries[args.service] = new_entry
    _encrypt_vault(entries, key)
    print(f"✅ Stored: {args.service}", file=sys.stderr)


def cmd_register(args) -> None:
    """Create a stub entry with source metadata but no value. First get triggers cache-through."""
    key = _get_key()
    entries = _decrypt_vault(key)
    if args.service in entries and "value" in entries[args.service] and entries[args.service]["value"]:
        print(f"⚠️  '{args.service}' already exists with a value. Use 'update' to change metadata.", file=sys.stderr)
        sys.exit(1)
    entries[args.service] = {
        "source": args.source,
        "expires": "—",
        "rotation_interval": args.rotation or "—",
        "notes": args.notes or "",
        "updated": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
    }
    _encrypt_vault(entries, key)
    print(f"✅ Registered: {args.service} → {args.source}", file=sys.stderr)


def cmd_refresh(args) -> None:
    """Force re-fetch from registered external source."""
    key = _get_key()
    entries = _decrypt_vault(key)
    entry = entries.get(args.service)
    if entry is None:
        print(f"Secret not found: '{args.service}'", file=sys.stderr)
        sys.exit(1)
    source = entry.get("source")
    if not source:
        print(f"No source registered for '{args.service}'", file=sys.stderr)
        sys.exit(1)
    fresh = _fetch_from_source(source)
    if fresh is None:
        print(f"Failed to fetch '{args.service}' from source: {source}", file=sys.stderr)
        sys.exit(1)
    rotation = entry.get("rotation_interval", "—")
    entry["value"] = fresh
    entry["expires"] = _expiry_from_rotation(rotation) if rotation and rotation != "—" else entry.get("expires", "—")
    entry["updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    _encrypt_vault(entries, key)
    print(f"🔄 Refreshed: {args.service} from {source.split('://')[0]}:// source", file=sys.stderr)


def cmd_delete(args) -> None:
    key = _get_key()
    entries = _decrypt_vault(key)
    if args.service not in entries:
        print(f"Secret not found: '{args.service}'", file=sys.stderr)
        sys.exit(1)
    del entries[args.service]
    _encrypt_vault(entries, key)
    print(f"🗑️  Deleted: {args.service}", file=sys.stderr)


def cmd_list(args) -> None:
    key = _get_key()
    entries = _decrypt_vault(key)
    scope = args.scope or ""
    matches = {k: v for k, v in entries.items() if k.startswith(scope)}
    if not matches:
        print("(no entries)", file=sys.stderr)
        return

    # Domain grouping by prefix
    _DOMAINS = {
        "pref-claude": ("🔧", "tooling"),
        "pref-github": ("🔧", "tooling"),
        "pref-node":   ("⚙️", "runtime"),
        "pref-python": ("⚙️", "runtime"),
        "pref-shell":  ("🐚", "shell"),
        "pref-vscode": ("✏️", "editor"),
    }

    # Table header
    filter_note = f" (filter: {scope})" if scope else ""
    print(f"Vault: {len(matches)} entries{filter_note}\n")
    print(f"{'':3} {'Domain':<35} {'Summary'}")
    print(f"{'':3} {'─'*35} {'─'*50}")

    for service, entry in sorted(matches.items()):
        notes = entry.get("notes", "")
        has_value = "value" in entry and entry["value"]
        source = entry.get("source", "")
        expires = entry.get("expires", "—")
        days = _days_until(expires)

        # Determine emoji + domain from prefix
        emoji, domain = "🔑", "credential"
        for prefix, (e, d) in _DOMAINS.items():
            if service.startswith(prefix):
                emoji, domain = e, d
                break

        # Short name: strip pref- prefix, derive ancestry
        short = service.removeprefix("pref-").removeprefix(f"{domain}-") if service.startswith("pref-") else service
        ancestry = f"{domain} ❯ {short}"

        # Summary: first meaningful chunk of notes, plus status
        summary = notes.split(" — ")[0].split(". ")[0] if notes else ""
        if days is not None and days <= 0:
            summary += " 🚨 EXPIRED"
        elif days is not None and days < 30:
            summary += f" 🔴 {days}d"

        # Value indicator for simple prefs
        if has_value and not notes:
            val = entry.get("value", "")
            if val in ("true", "false"):
                summary = "enabled" if val == "true" else "disabled"

        print(f" {emoji}  {ancestry:<34} {summary}")

    # Hint: use secrets.py list, not secrets.py get in a loop
    print(f"\n💡 To view a specific value: secrets.py get <service>", file=sys.stderr)


def cmd_audit(args) -> None:
    key = _get_key()
    entries = _decrypt_vault(key)
    scope = args.scope or ""
    matches = {k: v for k, v in entries.items() if k.startswith(scope)}

    found_any = False
    for service, entry in sorted(matches.items()):
        expires = entry.get("expires", "—")
        rotation = entry.get("rotation_interval", "—")
        days = _days_until(expires)
        if days is None:
            continue
        emoji, label, is_critical = _severity(days)
        found_any = True
        rot_hint = f" (rotation: {rotation})" if rotation and rotation != "—" else ""
        if is_critical and days < 15:
            _print_critical_block(service, days, expires)
            if rotation and rotation != "—":
                print(f"  ℹ️  Rotation interval: {rotation} — renew with: secrets.py set {service}", file=sys.stderr)
        else:
            day_str = f"{days}d" if days > 0 else "EXPIRED"
            print(f"{emoji} {label}: '{service}' expires {expires} ({day_str}){rot_hint}", file=sys.stderr)

    if not found_any:
        print("✅ All tracked secrets OK (no expiry warnings)", file=sys.stderr)


def cmd_migrate(args) -> None:
    """Import a secret from macOS Keychain into the vault."""
    account = args.account or "shell.m.shrader@qvc.com"
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-a", account, "-s", args.service, "-w"],
            capture_output=True, text=True, check=True
        )
        value = result.stdout.strip()
    except subprocess.CalledProcessError:
        print(f"Not found in Keychain: service='{args.service}' account='{account}'", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print("'security' command not available (not macOS?)", file=sys.stderr)
        sys.exit(2)

    key = _get_key()
    entries = _decrypt_vault(key)
    existing = entries.get(args.service, {})
    entries[args.service] = {
        "value": value,
        "expires": existing.get("expires", "—"),
        "rotation_interval": existing.get("rotation_interval", "—"),
        "notes": existing.get("notes", f"migrated from Keychain {date.today()}"),
        "updated": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
    }
    _encrypt_vault(entries, key)
    print(f"✅ Migrated from Keychain → vault: {args.service}", file=sys.stderr)


def cmd_update(args) -> None:
    """Update metadata (expires, rotation_interval, notes) for an existing entry without changing the value."""
    key = _get_key()
    entries = _decrypt_vault(key)
    if args.service not in entries:
        print(f"Secret not found: '{args.service}'", file=sys.stderr)
        sys.exit(1)
    if args.expires is not None:
        entries[args.service]["expires"] = args.expires
    if getattr(args, "rotation", None) is not None:
        entries[args.service]["rotation_interval"] = args.rotation
        # Auto-calculate expiry only if not explicitly given AND existing expiry is unknown or past
        if args.expires is None:
            existing_exp = entries[args.service].get("expires", "—")
            existing_days = _days_until(existing_exp)
            if existing_days is None or existing_days <= 0:
                auto = _expiry_from_rotation(args.rotation)
                if auto:
                    entries[args.service]["expires"] = auto
                    print(f"→ Expiry auto-calculated from rotation interval: {auto}", file=sys.stderr)
    if args.notes is not None:
        entries[args.service]["notes"] = args.notes
    entries[args.service]["updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    _encrypt_vault(entries, key)
    print(f"✅ Updated: {args.service}", file=sys.stderr)


def cmd_rekey(args) -> None:
    """Re-encrypt the vault with a new CSPRNG key."""
    old_key = _get_key()
    entries = _decrypt_vault(old_key)

    # Generate new key
    new_key = os.urandom(KEY_LEN)

    # Store in keychain if available
    if _HAS_KEYRING:
        try:
            if _keyring_set_with_timeout(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT, base64.b64encode(new_key).decode()):
                print("🔑 New key stored in OS keychain.", file=sys.stderr)
            else:
                # Timeout — fall back to file
                MASTER_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
                MASTER_KEY_FILE.write_bytes(new_key)
                MASTER_KEY_FILE.chmod(0o400)
                print(f"⚠️  Keychain write timed out. Written to {MASTER_KEY_FILE}", file=sys.stderr)
        except Exception as e:
            # Fall back to file
            MASTER_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
            MASTER_KEY_FILE.write_bytes(new_key)
            MASTER_KEY_FILE.chmod(0o400)
            print(f"⚠️  Could not store in keychain ({e}). Written to {MASTER_KEY_FILE}", file=sys.stderr)
    else:
        MASTER_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
        MASTER_KEY_FILE.write_bytes(new_key)
        MASTER_KEY_FILE.chmod(0o400)
        print(f"🔑 New key written to {MASTER_KEY_FILE} (chmod 0400).", file=sys.stderr)

    _encrypt_vault(entries, new_key)
    print(f"✅ Vault re-encrypted with new key ({len(entries)} entries preserved).", file=sys.stderr)



def main() -> None:
    parser = argparse.ArgumentParser(
        prog="secrets.py",
        description="Platform-agnostic AES-256-GCM encrypted workspace vault (v2 — keychain-backed)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_get = sub.add_parser("get", help="Retrieve a secret value (stdout)")
    p_get.add_argument("service")

    p_set = sub.add_parser("set", help="Store a secret")
    p_set.add_argument("service")
    p_set.add_argument("--value", help="Secret value (omit to read from stdin/prompt)")
    p_set.add_argument("--expires", help="Expiry date YYYY-MM-DD")
    p_set.add_argument("--rotation", help="Rotation interval (e.g. 90d, 6mo, 1y)")
    p_set.add_argument("--notes", help="Human-readable note")
    p_set.add_argument("--source", help="External source URI (e.g. op://vault/item/field)")

    p_del = sub.add_parser("delete", help="Remove a secret")
    p_del.add_argument("service")

    p_list = sub.add_parser("list", help="List vault entries")
    p_list.add_argument("--scope", help="Filter by service name prefix")

    p_audit = sub.add_parser("audit", help="Show expiry warnings")
    p_audit.add_argument("--scope", help="Filter by service name prefix")

    p_mig = sub.add_parser("migrate", help="Import from macOS Keychain")
    p_mig.add_argument("service")
    p_mig.add_argument("--account", help="Keychain account email")

    p_upd = sub.add_parser("update", help="Update expiry/rotation/notes without changing value")
    p_upd.add_argument("service")
    p_upd.add_argument("--expires", help="Expiry date YYYY-MM-DD")
    p_upd.add_argument("--rotation", help="Rotation interval (e.g. 90d, 6mo, 1y)")
    p_upd.add_argument("--notes", help="Human-readable note")

    p_reg = sub.add_parser("register", help="Register external source (stub — first get triggers fetch)")
    p_reg.add_argument("service")
    p_reg.add_argument("--source", required=True, help="External source URI (e.g. op://vault/item/field)")
    p_reg.add_argument("--rotation", help="Rotation interval (e.g. 90d, 6mo, 1y)")
    p_reg.add_argument("--notes", help="Human-readable note")

    p_refresh = sub.add_parser("refresh", help="Force re-fetch from registered external source")
    p_refresh.add_argument("service")

    sub.add_parser("rekey", help="Re-encrypt vault with new CSPRNG key")

    args = parser.parse_args()
    dispatch = {
        "get": cmd_get,
        "set": cmd_set,
        "delete": cmd_delete,
        "list": cmd_list,
        "audit": cmd_audit,
        "migrate": cmd_migrate,
        "update": cmd_update,
        "register": cmd_register,
        "refresh": cmd_refresh,
        "rekey": cmd_rekey,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
