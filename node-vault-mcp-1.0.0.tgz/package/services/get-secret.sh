#!/usr/bin/env bash
# services/get-secret.sh — retrieve a secret from the keychain-backed workspace vault
#
# The vault master key is resolved via: SECRETS_KEY env → OS keychain → ~/.claude/master.key
# No passphrase needed — zero-config on workstations with `keyring` installed.
#
# Usage:  services/get-secret.sh <service-name> [account]
# Output: secret value on stdout (no trailing newline)
# Exit:   0 on success, 1 if not found

set -euo pipefail

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  echo "Usage: get-secret.sh <service-name>"
  echo "  Retrieve a secret from the keychain-backed workspace vault."
  echo "  Output: secret value on stdout (no trailing newline)"
  echo "  Exit: 0 on success, 1 if not found"
  exit 0
fi

SERVICE="${1:-}"

if [[ -z "$SERVICE" ]]; then
  echo "Usage: $(basename "$0") <service-name> [account]" >&2
  exit 1
fi

python3 "$(dirname "$0")/secrets.py" get "$SERVICE"
