"""vault_secrets.core — public Python API for the encrypted vault.

Two API surfaces:
  (a.1) Metadata-only public API (8 vault_* functions): list, audit, status,
        providers, update, delete, register, refresh. Never returns values.
        Mirrored as MCP tools via secrets_server/tools.py.
  (a.2) Value-readers (get_pref_value, get_secret_value): return actual values
        for in-process Python consumers. Not exposed via MCP.
        Guarded by ISAAC_MCP_NO_VALUE_READ env var (raises inside MCP process).

Also consumed by secrets.py bash CLI (surface b) via importlib.

Secret values never appear in MCP tool interfaces. No vault_set or vault_get
tools exist by design.
"""
import importlib.util
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

# ── Paths ────────────────────────────────────────────────────────────────────
# vault_secrets/core.py → vault_secrets/ → services/  →  secrets.py sibling
_SERVICES_DIR = Path(__file__).resolve().parent.parent
_SECRETS_SCRIPT = _SERVICES_DIR / "secrets.py"
_PROVIDERS_DIR = _SERVICES_DIR / "vault_secrets" / "providers"

# Cache for the lazy-loaded secrets.py helpers module.
_cached_secrets_mod = None


def _secrets_mod():
    """Lazy-load services/secrets.py as a Python module via importlib.

    Loaded under a non-shadowing name (`_node_vault_secrets_helpers`) to avoid
    stdlib `secrets` collision. Cached after first call.
    """
    global _cached_secrets_mod
    if _cached_secrets_mod is not None:
        return _cached_secrets_mod
    spec = importlib.util.spec_from_file_location(
        "_node_vault_secrets_helpers", str(_SECRETS_SCRIPT)
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _cached_secrets_mod = mod
    return mod


# ── Envelope helpers ─────────────────────────────────────────────────────────


def _ok(payload) -> str:
    """JSON OK envelope. dict payload merges top-level; non-dict wraps in {"data": ...}."""
    if isinstance(payload, dict):
        return json.dumps({"ok": True, **payload}, default=str, indent=2)
    return json.dumps({"ok": True, "data": payload}, default=str, indent=2)


def _error(message: str, **extra) -> str:
    """JSON error envelope."""
    payload = {"ok": False, "error": message}
    payload.update(extra)
    return json.dumps(payload, default=str)


def _write_guard(action: str, consequence: str, confirmed: bool) -> "str | None":
    """Operator approval gate — blocks writes until the agent confirms with the operator.

    Returns a rejection envelope when confirmed=False. Returns None (proceed)
    when confirmed=True. The agent MUST present the action and consequence to
    the operator and receive explicit approval before re-calling with
    confirmed=True — even if the operator's prior message appeared to authorize
    the action. The consequence may reveal information the operator didn't
    consider when they made the request.
    """
    if confirmed:
        return None
    return json.dumps({
        "ok": False,
        "needs_confirmation": True,
        "action": action,
        "consequence": consequence,
        "instruction": (
            "STOP. Present this action and consequence to the operator. "
            "Do not set confirmed=True until the operator has seen the consequence "
            "and explicitly approved. Re-call with confirmed=True only after approval."
        ),
    }, default=str)


# ── (a.1) Public API — metadata + writes; NEVER returns secret values ─────────


def vault_list(scope: str = "") -> str:
    """List vault entries — names, expiry dates, and sources only.

    SECURITY: secret values are never returned (Zero Tolerance). Metadata only.
    Args:
        scope: optional prefix filter (e.g. "pref-" for preferences).
    """
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        prefix = scope.strip()
        filtered = (
            {k: v for k, v in entries.items() if k.startswith(prefix)}
            if prefix
            else entries
        )
        rows = []
        for service, entry in sorted(filtered.items()):
            rows.append({
                "service": service,
                "expires": entry.get("expires", "—") or "—",
                "source": entry.get("source", "") or "",
                "has_value": bool(entry.get("value")),
                "rotation_interval": entry.get("rotation_interval", "—") or "—",
                "notes": entry.get("notes", "") or "",
                "updated": entry.get("updated", "") or "",
            })
        return _ok({
            "operation": "vault_list",
            "scope": scope or "(all)",
            "count": len(rows),
            "entries": rows,
            "security_note": "Secret values are never returned by this function.",
        })
    except Exception as exc:
        return _error(str(exc))


def vault_audit(scope: str = "") -> str:
    """Audit vault entries for expiry — surfaces entries expired or expiring within 7 days.

    SECURITY: secret values are never returned (Zero Tolerance). Metadata only.
    Args:
        scope: optional prefix filter.
    """
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        prefix = scope.strip()
        filtered = (
            {k: v for k, v in entries.items() if k.startswith(prefix)}
            if prefix
            else entries
        )
        warnings = []
        for service, entry in sorted(filtered.items()):
            expires = entry.get("expires", "—") or "—"
            days = sec._days_until(expires)
            if days is None:
                continue
            if days <= 0:
                warnings.append({
                    "service": service,
                    "status": "expired",
                    "days": days,
                    "expires": expires,
                })
            elif days <= 7:
                warnings.append({
                    "service": service,
                    "status": "expiring_soon",
                    "days": days,
                    "expires": expires,
                })
        return _ok({
            "operation": "vault_audit",
            "scope": scope or "(all)",
            "warnings_count": len(warnings),
            "warnings": warnings,
            "security_note": "Secret values are never returned by this function.",
        })
    except Exception as exc:
        return _error(str(exc))


def vault_status(service: str) -> str:
    """Check whether a specific vault entry exists and its expiry metadata.

    Part of the Vault-First Consumer Pattern. SECURITY: never returns values.
    """
    if not service.strip():
        return _error("service name must not be empty")
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        entry = entries.get(service.strip())
        if entry is None:
            return _ok({"service": service, "exists": False, "has_value": False})
        return _ok({
            "service": service,
            "exists": True,
            "has_value": bool(entry.get("value")),
            "expires": entry.get("expires", ""),
            "source": entry.get("source", ""),
            "notes": entry.get("notes", ""),
            "security_note": "Secret values are never returned.",
        })
    except Exception as exc:
        return _error(str(exc))


def vault_providers() -> str:
    """List available vault source providers — scans services/vault_secrets/providers/*.py.

    No isaac.db dependency (asymmetric: node-vault-mcp ⊥ isaac). isaac-db.py
    sync_providers() consumes the result of this function and writes to its
    own providers table.
    """
    try:
        rows = []
        if _PROVIDERS_DIR.is_dir():
            for f in sorted(_PROVIDERS_DIR.glob("*.py")):
                if f.name.startswith("_"):
                    continue
                row = {
                    "scheme": f.stem,
                    "module_path": str(f),
                    "description": "",
                    "detect_cmd": "",
                    "available": False,
                }
                try:
                    spec = importlib.util.spec_from_file_location(
                        f"_vault_provider_{f.stem}", f
                    )
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)
                except Exception as exc:
                    row["error"] = str(exc)
                    rows.append(row)
                    continue
                row["scheme"] = getattr(mod, "SCHEME", f.stem)
                row["description"] = getattr(mod, "DESCRIPTION", "")
                row["detect_cmd"] = getattr(mod, "DETECT_CMD", "") or ""
                if row["detect_cmd"]:
                    first = row["detect_cmd"].split()[0] if row["detect_cmd"].split() else row["detect_cmd"]
                    row["available"] = shutil.which(first) is not None
                else:
                    row["available"] = True
                rows.append(row)
        return _ok({
            "operation": "vault_providers",
            "count": len(rows),
            "providers": rows,
        })
    except Exception as exc:
        return _error(str(exc))


def vault_update(
    service: str,
    notes: str = "",
    expires: str = "",
    rotation: str = "",
    confirmed: bool = False,
) -> str:
    """Update metadata (notes, expiry, rotation) on an existing vault entry.

    WRITE GUARD: requires confirmed=True. Metadata only — secret value preserved.
    """
    guard = _write_guard(
        f"Update vault metadata for '{service.strip()}'",
        f"Modifies notes/expiry/rotation on '{service.strip()}'. Secret value is preserved, but expiry changes affect when other tools treat the credential as valid.",
        confirmed,
    )
    if guard:
        return guard
    if not service.strip():
        return _error("service name must not be empty")
    if not notes.strip() and not expires.strip() and not rotation.strip():
        return _error("At least one of notes, expires, or rotation must be provided.")
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        svc = service.strip()
        if svc not in entries:
            return _error(f"Secret not found: '{svc}'")
        if expires.strip():
            entries[svc]["expires"] = expires.strip()
        if rotation.strip():
            entries[svc]["rotation_interval"] = rotation.strip()
            if not expires.strip():
                existing_exp = entries[svc].get("expires", "—")
                existing_days = sec._days_until(existing_exp)
                if existing_days is None or existing_days <= 0:
                    auto = sec._expiry_from_rotation(rotation.strip())
                    if auto:
                        entries[svc]["expires"] = auto
        if notes.strip():
            entries[svc]["notes"] = notes.strip()
        entries[svc]["updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        sec._encrypt_vault(entries, key)
        return _ok({
            "operation": "vault_update",
            "service": svc,
            "security_note": "Only metadata was updated. Secret value was not touched.",
        })
    except Exception as exc:
        return _error(str(exc))


def vault_delete(service: str, confirmed: bool = False) -> str:
    """Delete a vault entry permanently. Irreversible.

    WRITE GUARD: requires confirmed=True.
    """
    guard = _write_guard(
        f"Delete vault entry '{service.strip()}'",
        f"PERMANENTLY DESTROYS '{service.strip()}' — the encrypted secret value, metadata, expiry, and source registration are all deleted. This cannot be recovered. If this credential is in active use, dependent systems will fail on their next auth attempt.",
        confirmed,
    )
    if guard:
        return guard
    if not service.strip():
        return _error("service name must not be empty")
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        svc = service.strip()
        if svc not in entries:
            return _error(f"Secret not found: '{svc}'")
        del entries[svc]
        sec._encrypt_vault(entries, key)
        return _ok({"operation": "vault_delete", "service": svc})
    except Exception as exc:
        return _error(str(exc))


def vault_register(
    service: str,
    source: str,
    rotation: str = "",
    notes: str = "",
    confirmed: bool = False,
) -> str:
    """Register an external source for a vault entry. No secret value handled.

    WRITE GUARD: requires confirmed=True. Creates a stub pointing to source URI;
    actual fetch happens on first secrets.py get via the registered provider.
    """
    guard = _write_guard(
        f"Register external source for '{service.strip()}'",
        f"Creates a stub entry for '{service.strip()}' pointing to source URI '{source.strip()}'. No secret value is stored yet — the first `secrets.py get` will fetch from this source and cache the result. If the source URI is wrong, the first fetch will fail or store the wrong credential.",
        confirmed,
    )
    if guard:
        return guard
    if not service.strip():
        return _error("service name must not be empty")
    if not source.strip():
        return _error("source URI must not be empty (e.g., op://vault/item/field)")
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        svc = service.strip()
        if svc in entries and entries[svc].get("value"):
            return _error(
                f"'{svc}' already exists with a value. Use vault_update to change metadata."
            )
        entries[svc] = {
            "source": source.strip(),
            "expires": "—",
            "rotation_interval": rotation.strip() or "—",
            "notes": notes.strip() or "",
            "updated": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        }
        sec._encrypt_vault(entries, key)
        return _ok({
            "operation": "vault_register",
            "service": svc,
            "source": source.strip(),
            "security_note": "No secret value was handled. Stub entry created for cache-through on first get.",
        })
    except Exception as exc:
        return _error(str(exc))


def vault_refresh(service: str, confirmed: bool = False) -> str:
    """Force re-fetch a vault entry from its registered external source.

    WRITE GUARD: requires confirmed=True. Fetched value is never returned.
    """
    guard = _write_guard(
        f"Refresh vault entry '{service.strip()}' from external source",
        f"Overwrites the cached secret value for '{service.strip()}' with a fresh fetch from its registered source. If the source credential has been rotated, this will pick up the new value. If the source is unreachable, the existing cached value is preserved (no data loss).",
        confirmed,
    )
    if guard:
        return guard
    if not service.strip():
        return _error("service name must not be empty")
    try:
        sec = _secrets_mod()
        key = sec._get_key()
        entries = sec._decrypt_vault(key)
        svc = service.strip()
        entry = entries.get(svc)
        if entry is None:
            return _error(f"Secret not found: '{svc}'")
        source = entry.get("source")
        if not source:
            return _error(f"No source registered for '{svc}'")
        fresh = sec._fetch_from_source(source)
        if fresh is None:
            return _error(f"Failed to fetch '{svc}' from source: {source}")
        rotation = entry.get("rotation_interval", "—")
        entry["value"] = fresh
        if rotation and rotation != "—":
            auto = sec._expiry_from_rotation(rotation)
            if auto:
                entry["expires"] = auto
        entry["updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        sec._encrypt_vault(entries, key)
        return _ok({
            "operation": "vault_refresh",
            "service": svc,
            "source_scheme": source.split("://")[0] if "://" in source else "unknown",
            "security_note": "Secret value was refreshed from source but is never returned.",
        })
    except Exception as exc:
        return _error(str(exc))


# ── (a.2) Python-only value-readers — NOT exposed via MCP ────────────────────


def _value_read_guard():
    """Defense-in-depth: refuse to resolve inside the node-vault-mcp stdio process.

    services/node-vault-mcp.py sets ISAAC_MCP_NO_VALUE_READ=1 in os.environ at
    startup. Importing get_pref_value/get_secret_value inside that process and
    calling them raises — preventing accidental wrap-as-MCP-tool.
    """
    if os.environ.get("ISAAC_MCP_NO_VALUE_READ") == "1":
        raise RuntimeError(
            "vault_secrets.core value-readers (get_pref_value / get_secret_value) "
            "must not be invoked inside the node-vault-mcp stdio process. "
            "Use the metadata-only (a.1) public API surface instead. "
            "If you reached this from a hook or generator, ensure ISAAC_MCP_NO_VALUE_READ "
            "is unset in that process's environment."
        )


def get_pref_value(key: str) -> "str | None":
    """Return the value of a pref-* vault entry, or None if absent.

    SCOPE: pref-* keys ONLY. Raises ValueError on any other key — this restricts
    the function's reach to preference values, never credential values.

    Use cases (in-process Python only):
      - gen_aliases.py / gen-settings.py reading pref-claude-permissions-mode
      - hooks reading pref-emojis, pref-copilot-whisper-mode, etc.
      - whisper-watcher.py reading pref-instance-id

    NOT exposed via MCP. NOT exposed via HTTP. NOT decorated as @mcp.tool.
    """
    if not isinstance(key, str) or not key.startswith("pref-"):
        raise ValueError(
            f"get_pref_value() only accepts keys starting with 'pref-'; got: {key!r}"
        )
    _value_read_guard()
    sec = _secrets_mod()
    try:
        master = sec._get_key()
        entries = sec._decrypt_vault(master)
    except Exception:
        return None
    entry = entries.get(key)
    if not entry:
        return None
    value = entry.get("value", "")
    return value or None


def get_secret_value(service: str) -> "str | None":
    """Return the value of a vault entry (any key), or None if absent.

    Used by federation_auth (federation-key-<instance_id>) and the bash
    git-credential helper for synman-github-pat. Python-only — never MCP.
    """
    if not isinstance(service, str) or not service.strip():
        raise ValueError("get_secret_value() requires a non-empty service name")
    _value_read_guard()
    sec = _secrets_mod()
    try:
        master = sec._get_key()
        entries = sec._decrypt_vault(master)
    except Exception:
        return None
    entry = entries.get(service.strip())
    if not entry:
        return None
    value = entry.get("value", "")
    return value or None
