#!/usr/bin/env python3
"""macOS Keychain provider for vault cache-through.

# Scheme: keychain
# Description: macOS Keychain (security find-generic-password)
# Detect: security
"""

import subprocess
import sys

SCHEME = "keychain"
DESCRIPTION = "macOS Keychain (security find-generic-password)"
DETECT_CMD = "security"


def fetch(uri: str) -> str | None:
    """Fetch from macOS Keychain. URI format: keychain://service/account"""
    parts = uri.removeprefix("keychain://").split("/", 1)
    if len(parts) != 2:
        print(f"⚠️  Invalid keychain URI (expected keychain://service/account): {uri}", file=sys.stderr)
        return None
    service, account = parts
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-a", account, "-s", service, "-w"],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            return result.stdout.strip()
        print(f"⚠️  Keychain fetch failed: {result.stderr.strip()}", file=sys.stderr)
        return None
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        print(f"⚠️  Keychain fetch error: {e}", file=sys.stderr)
        return None
