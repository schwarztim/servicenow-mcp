#!/usr/bin/env python3
"""Environment variable provider for vault cache-through.

# Scheme: env
# Description: Environment variable lookup
# Detect: (always available)
"""

import os
import sys

SCHEME = "env"
DESCRIPTION = "Environment variable lookup"
DETECT_CMD = None  # always available


def fetch(uri: str) -> str | None:
    """Fetch from environment variable. URI format: env://VAR_NAME"""
    var = uri.removeprefix("env://")
    value = os.environ.get(var)
    if value is None:
        print(f"⚠️  Environment variable not set: {var}", file=sys.stderr)
    return value
