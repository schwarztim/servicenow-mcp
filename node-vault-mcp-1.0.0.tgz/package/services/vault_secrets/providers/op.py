#!/usr/bin/env python3
"""1Password CLI provider for vault cache-through.

# Scheme: op
# Description: 1Password CLI (op read)
# Detect: op
"""

import subprocess
import sys

SCHEME = "op"
DESCRIPTION = "1Password CLI (op read)"
DETECT_CMD = "op"


def fetch(uri: str) -> str | None:
    """Fetch secret from 1Password. URI format: op://vault/item/field"""
    try:
        result = subprocess.run(
            ["op", "read", uri],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            return result.stdout.strip()
        print(f"⚠️  1Password fetch failed: {result.stderr.strip()}", file=sys.stderr)
        return None
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        print(f"⚠️  1Password fetch error: {e}", file=sys.stderr)
        return None
