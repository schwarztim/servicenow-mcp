#!/usr/bin/env python3
"""GitHub CLI provider for vault cache-through.

# Scheme: gh
# Description: GitHub CLI (gh auth token)
# Detect: gh
"""

import subprocess
import sys

SCHEME = "gh"
DESCRIPTION = "GitHub CLI (gh auth token)"
DETECT_CMD = "gh"


def fetch(uri: str) -> str | None:
    """Fetch from GitHub CLI. URI format: gh://auth/token"""
    path = uri.removeprefix("gh://")
    if path == "auth/token":
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                return result.stdout.strip()
            print(f"⚠️  gh auth token failed: {result.stderr.strip()}", file=sys.stderr)
            return None
        except (subprocess.TimeoutExpired, FileNotFoundError) as e:
            print(f"⚠️  gh fetch error: {e}", file=sys.stderr)
            return None
    print(f"⚠️  Unsupported gh URI path: {path}", file=sys.stderr)
    return None
