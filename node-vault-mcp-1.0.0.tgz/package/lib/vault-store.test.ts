import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { mkdir, readFile, rm, stat, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

import { VaultStore } from "./vault-store.js";

type Workspace = {
  root: string;
  vaultPath: string;
  masterKeyPath: string;
};

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
let workspaceCounter = 0;

test("set/get roundtrip writes Vault V2 with secure permissions", async (t) => {
  const workspace = await createWorkspace("roundtrip");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  await store.set("hermes", "ms365:graph", "top-secret");

  assert.equal(await store.get("hermes", "ms365:graph"), "top-secret");
  assert.equal(await store.getPassword("hermes", "ms365:graph"), "top-secret");

  const rawVault = await readRawVault(workspace.vaultPath);
  assert.deepEqual(rawVault.meta, {
    version: "2",
    algo: "AES-256-GCM",
    key_source: "file",
  });
  assert.ok(rawVault.entries["hermes::ms365:graph"]);

  const vaultStat = await stat(workspace.vaultPath);
  assert.equal(vaultStat.mode & 0o777, 0o600);
});

test("findCredentials returns matching service entries only", async (t) => {
  const workspace = await createWorkspace("find-credentials");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  await store.setPassword("hermes", "ms365:graph", "alpha");
  await store.setPassword("hermes", "jira", "beta");
  await store.setPassword("other", "jira", "gamma");

  assert.deepEqual(await store.findCredentials("hermes"), [
    { account: "jira", password: "beta" },
    { account: "ms365:graph", password: "alpha" },
  ]);
});

test("delete removes an entry and reports missing entries", async (t) => {
  const workspace = await createWorkspace("delete");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  await store.set("hermes", "ms365:graph", "to-delete");

  assert.equal(await store.delete("hermes", "ms365:graph"), true);
  assert.equal(await store.get("hermes", "ms365:graph"), null);
  assert.equal(await store.deletePassword("hermes", "ms365:graph"), false);
});

test("empty or missing vault behaves as an empty store", async (t) => {
  const workspace = await createWorkspace("empty-vault");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  assert.equal(await store.get("hermes", "ms365:graph"), null);
  assert.deepEqual(await store.findCredentials("hermes"), []);
  assert.equal(await store.delete("hermes", "ms365:graph"), false);

  await writeFile(workspace.vaultPath, "", { encoding: "utf8", mode: 0o600 });

  assert.equal(await store.getPassword("hermes", "ms365:graph"), null);
});

test("writes Python-compatible Vault V2 entries", async (t) => {
  const workspace = await createWorkspace("python-interop");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  await store.setPassword("interop", "account", "shared-secret");

  const rawVault = await readRawVault(workspace.vaultPath);
  const entry = rawVault.entries["interop::account"];
  assert.ok(entry);
  assert.equal(Buffer.from(entry.nonce, "base64").length, 12);
  assert.ok(Buffer.from(entry.ciphertext, "base64").length > 16);

  const pythonResult = spawnSync(
    "python3",
    [
      "-c",
      [
        "import base64, json, sys",
        "from pathlib import Path",
        "try:",
        "    from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
        "except ImportError:",
        "    print('cryptography package required', file=sys.stderr)",
        "    raise SystemExit(3)",
        "service = sys.argv[1]",
        "vault_path = Path(sys.argv[2])",
        "master_key_path = Path(sys.argv[3])",
        "raw = json.loads(vault_path.read_text())",
        "enc = raw['entries'][service]",
        "nonce = base64.b64decode(enc['nonce'])",
        "ciphertext = base64.b64decode(enc['ciphertext'])",
        "key = master_key_path.read_bytes()",
        "plain = AESGCM(key).decrypt(nonce, ciphertext, service.encode())",
        "print(json.loads(plain)['value'], end='')",
      ].join("\n"),
      "interop::account",
      workspace.vaultPath,
      workspace.masterKeyPath,
    ],
    {
      cwd: projectRoot,
      encoding: "utf8",
    },
  );

  if (pythonResult.status === 0) {
    assert.equal(pythonResult.stdout, "shared-secret");
    return;
  }

  const combinedOutput = `${pythonResult.stdout}${pythonResult.stderr}`;
  if (combinedOutput.includes("cryptography package required")) {
    t.diagnostic("Python cryptography unavailable; validated raw Vault V2 binary layout instead.");
    return;
  }

  assert.fail(`Python interop failed: ${combinedOutput}`);
});

test("rejects wrong master key with a decryption error", async (t) => {
  const workspace = await createWorkspace("wrong-key");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  await store.set("hermes", "ms365:graph", "secret-value");

  // Overwrite master key with a different random key
  const wrongKeyPath = workspace.masterKeyPath;
  await writeFile(wrongKeyPath, randomBytes(32), { mode: 0o600 });

  const wrongKeyStore = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: wrongKeyPath,
  });

  await assert.rejects(
    () => wrongKeyStore.get("hermes", "ms365:graph"),
    (error: unknown) => error instanceof Error,
    "Should throw on decryption with wrong key",
  );
});

test("concurrent writes never corrupt the vault and preserve every write", async (t) => {
  // Regression for two failure modes:
  //   (1) Byte-level interleave: previous implementation used a fixed
  //       `${vaultPath}.tmp` temp path. Two concurrent writers wrote into the
  //       same intermediate file at offset 0, leaving the longer payload's
  //       tail past the shorter payload's closing brace → "Extra data" parse
  //       errors on next vault load. Fix: PID + random suffix on temp path.
  //   (2) Lost writes from RMW race: two setPassword calls each do
  //       read-vault → mutate → write-vault. Without serialization, both can
  //       read the same baseline, both mutate independently, and the second
  //       rename silently overwrites the first writer's entry. Fix: in-process
  //       async mutex (withWriteLock) around the entire RMW cycle.
  const workspace = await createWorkspace("concurrent");
  t.after(async () => cleanupWorkspace(workspace));

  const store = new VaultStore({
    vaultPath: workspace.vaultPath,
    masterKeyPath: workspace.masterKeyPath,
  });

  // Seed an initial entry so the vault file exists before the race
  await store.set("hermes", "seed", "seed-value");

  const writerCount = 25;
  const writers: Array<Promise<void>> = [];
  for (let i = 0; i < writerCount; i++) {
    writers.push(store.set("hermes", `concurrent-${i}`, `value-${i}`));
  }
  await Promise.all(writers);

  // Invariant 1: vault file is valid JSON (no extra data after closing brace).
  const fileText = await readFile(workspace.vaultPath, "utf8");
  const parsed = JSON.parse(fileText);
  assert.equal(parsed.meta.version, "2");

  // Invariant 2: EVERY concurrent write persists (lost-write regression).
  for (let i = 0; i < writerCount; i++) {
    const value = await store.getPassword("hermes", `concurrent-${i}`);
    assert.equal(value, `value-${i}`, `concurrent-${i} was lost or corrupted`);
  }

  // Invariant 3: seed entry survived the race (older entries not clobbered).
  assert.equal(await store.getPassword("hermes", "seed"), "seed-value");

  // Invariant 4: no leftover temp files in the vault dir.
  const { readdir } = await import("node:fs/promises");
  const siblings = await readdir(dirname(workspace.vaultPath));
  const strays = siblings.filter((n) => n.startsWith("secrets.vault.tmp"));
  assert.deepEqual(strays, [], `stray temp files left behind: ${strays.join(", ")}`);
});

async function createWorkspace(name: string): Promise<Workspace> {
  const root = join(projectRoot, ".test-artifacts", `${sanitizeName(name)}-${process.pid}-${workspaceCounter++}`);
  const claudeDir = join(root, ".claude");
  const masterKeyPath = join(claudeDir, "master.key");
  const vaultPath = join(claudeDir, "secrets.vault");

  await rm(root, { recursive: true, force: true });
  await mkdir(claudeDir, { recursive: true });
  await writeFile(masterKeyPath, randomBytes(32), { mode: 0o600 });

  return { root, vaultPath, masterKeyPath };
}

async function cleanupWorkspace(workspace: Workspace): Promise<void> {
  await rm(workspace.root, { recursive: true, force: true });
}

async function readRawVault(vaultPath: string): Promise<{
  meta: { version: string; algo: string; key_source: string };
  entries: Record<string, { nonce: string; ciphertext: string }>;
}> {
  const fileText = await readFile(vaultPath, "utf8");
  return JSON.parse(fileText) as {
    meta: { version: string; algo: string; key_source: string };
    entries: Record<string, { nonce: string; ciphertext: string }>;
  };
}

function sanitizeName(value: string): string {
  return value.replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase() || "test";
}
