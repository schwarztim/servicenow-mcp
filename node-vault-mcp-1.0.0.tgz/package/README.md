# node-vault-mcp

Self-standing MCP app for Isaac vault & secrets management. Application-tier app under the `security/` project tier of the Isaac workspace.

## Architecture

Three first-class surfaces backed by a single shared `vault_secrets.core` Python module:

- **(a) Native Python import** — `from vault_secrets.core import vault_status, vault_audit, ...` for in-process consumers (gen-settings, hooks, federation_auth, etc.).
- **(b) Bash CLI** — `services/secrets.py` for non-Python callers (e.g. `dt-mcp.py` subprocess pattern).
- **(c) MCP stdio** — `mcp__node-vault-mcp__vault_*` tools for LLM agents, registered in `~/.claude/settings.json` `mcpServers` as a per-session subprocess.

**No HTTP. No daemon. No listening port.** Pure in-process Python + stdio MCP.

## Asymmetric Dependency

- `node-vault-mcp ⊥ isaac` — zero isaac knowledge in committed code. Cloneable + runnable standalone.
- `isaac → node-vault-mcp` via `pip install -e ~/ai/claude-isaac/security/node-vault-mcp` declared in isaac's `requirements.txt`.

## Install

```bash
pip install -e ~/ai/claude-isaac/security/node-vault-mcp
```

The `vault_secrets` Python package becomes importable from any virtualenv that ran the install. The package name is intentionally `vault_secrets` (NOT `secrets`) to avoid shadowing the Python stdlib `secrets` module on `sys.path`.

## Vault tools (8)

| Tool | Purpose |
|------|---------|
| `vault_list` | List entries (metadata) |
| `vault_audit` | Expiry warnings |
| `vault_status` | Check entry exists + has_value |
| `vault_providers` | List source providers |
| `vault_update` | Update notes/expiry/rotation |
| `vault_delete` | Delete entry |
| `vault_register` | Register external source |
| `vault_refresh` | Re-fetch from source |

**No `vault_set` or `vault_get` MCP tools — by design.** Secret values must never appear in MCP tool interfaces (session transcripts persist plaintext to disk). Use `services/secrets.py set` / `secrets.py get` from a separate terminal for credential storage and read.

## CLAUDE.md

See `CLAUDE.md` for application-tier rules and the security-peer lifecycle mandate.

## License

Same as the parent Isaac workspace.
