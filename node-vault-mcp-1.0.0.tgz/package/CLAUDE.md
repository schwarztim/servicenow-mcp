# node-vault-mcp — Claude Code Rules

> Global rules in `~/.claude/CLAUDE.md` + `~/.claude/rules/*.md` are always in effect. This file adds application-tier guidance.

## Architecture

**Tier:** application (under `security/` project tier — sibling to `collab-tools/`).
**Source:** `~/ai/claude-isaac/security/node-vault-mcp/`

Self-standing app for vault + secrets. Three surfaces, one core:

```
vault_secrets.core   ←──────────┐
        ▲                       │
        │ (a) native import     │ (a.2) get_pref_value / get_secret_value
        │                       │     Python-only — NEVER MCP-exposed
        ├── isaac Python consumers (gen-settings, hooks, federation_auth, ...)
        │
        │ (b) bash CLI                  → services/secrets.py
        │     (dt-mcp.py subprocess pattern)
        │
        │ (c) MCP stdio                 → services/node-vault-mcp.py
              mcp__node-vault-mcp__vault_*      registered in settings.json mcpServers
```

**No HTTP. No daemon. No listening port.**

## Stack

- **Language:** Python 3.11+
- **Transport:** stdio (FastMCP)
- **Package:** `vault_secrets` (non-shadowing — avoids stdlib `secrets` collision)
- **Build:** hatchling (`pyproject.toml`)

## Lifecycle Invariant (Security-Peer Mandate)

`services/node-vault-mcp.py` MUST NOT spawn child processes via `subprocess.run` / `subprocess.Popen` / `os.system` / `os.exec*` / `os.fork` / `multiprocessing.*` / threading. All vault operations are pure in-process Python (read/decrypt/encrypt vault file via `vault_secrets.core`).

**Why:** for a security peer storing encryption keys, orphan or leaked subprocess state is unacceptable. Direct architectural evidence: the dt-mcp orphan incident (`services/dt-mcp.py:110-118` spawns npx grandchildren without `finally` / `atexit` / signal cleanup) demonstrated that unmanaged child-process patterns are unsafe in peer MCP apps.

**Enforcement:** AST-walker in `~/ai/claude-isaac/services/safety_invariants.py` (added in plan batch-7) scans `services/node-vault-mcp.py` for forbidden imports and call patterns. Process-tree shape on a CC session must remain `claude → node-vault-mcp.py` (one stdio child of CC, dies with CC via SIGHUP/parent-exit). No grandchildren.

## Defense-in-Depth: Value-Read Containment

`vault_secrets.core` exposes two distinct sub-surfaces:

- **(a.1) MCP-mirrorable public API** — `vault_list`, `vault_audit`, `vault_status`, `vault_providers`, `vault_update`, `vault_delete`, `vault_register`, `vault_refresh`. **NEVER returns secret values.** Metadata + writes only.
- **(a.2) Python-only value-readers** — `get_pref_value(key)` and `get_secret_value(service)`. **DO** return values, for in-process consumers (gen_aliases, hooks, whisper-watcher, isaac-mcp.py startup) that need actual values not metadata. Structural guards:
  - `get_pref_value(key)` raises `ValueError` if `key` does not start with `pref-` (allowlist enforced in code).
  - Both functions are NOT decorated with `@mcp.tool`, NOT exposed via FastMCP, NOT wrapped in any HTTP route.
  - Defense-in-depth: both functions check `ISAAC_MCP_NO_VALUE_READ=1` env var (set by `services/node-vault-mcp.py` stdio entry at startup) and raise if set — prevents accidental import of these functions inside the MCP-server process where they could be wrapped as tools.

## Zero-Tolerance Rule (Repeated Verbatim)

> **No `vault_set` or `vault_get` MCP tools exist by design** — secret values must never appear in MCP tool interfaces (session transcripts persist plaintext to `~/.claude/projects/<dir>/<session>.jsonl`).

This rule is REPEATED VERBATIM in `~/ai/claude-isaac/rules/security.md` (intentional duplication for safety — visible in both repos' rules). Adding `vault_set` or `vault_get` MCP tools is forbidden.

## Master-Key Resolution Chain (Preserved Verbatim)

1. `SECRETS_KEY` env var (base64-encoded 32-byte key — for CI/containers)
2. `~/.claude/master.key` file (mode 0400)
3. OS keychain via `keyring` library (`claude-secrets-vault` service)
4. Fail closed with actionable error

The `SECRETS_KEY` env-override path is preserved as documented existing behavior — known bypass surface, NOT a non-regression introduced by this app. Structural gating of the env-override is OUT OF SCOPE for this app and tracked under follow-up proposal `secrets-key-env-structural-gating`.

## Vault File Location

`~/.claude/secrets.vault` — single-host, AES-256-GCM. Location is unchanged across the isaac → node-vault-mcp decouple. Each fleet instance keeps its own vault.

## Bash-CLI Compatibility Symlink (Operator-Directed Exception)

The Round-15 clean-break amendment removed shims for in-process Python consumers
(no `vault_client.py`, all `vault_*` MCP tools and `/api/vault/*` HTTP routes
DELETED from isaac). External bash callers — `.zshrc` exports, `.bashrc`
aliases, LaunchAgents, cron jobs, IDE run configs, or any operator-personal
script invoking `~/ai/claude-isaac/services/secrets.py` directly — would break
silently after batch-5 deletes the old path (`2>/dev/null` masks the failure).

**Approved exception:** maintain a single-file symlink

```
~/ai/claude-isaac/services/secrets.py
    → ~/ai/claude-isaac/security/node-vault-mcp/services/secrets.py
```

Owned by `services/install-hooks.sh` (idempotent `ln -sfn`, runs on every
install / sync). `services/get-secret.sh` follows the same pattern if/when an
external caller needs it. Scope: bash CLI surface (b) ONLY — no equivalent
shim for the deleted MCP tool namespace (`mcp__isaac-mcp__vault_*`) or HTTP
routes (`/api/vault/*`); those breaks are intentional per plan.

**Why this is a narrowly-scoped exception, not a real shim:**
- Filesystem alias only — no dual code path, no logic difference, identical
  behavior whether called via old or new path.
- Targets the operator's external scripts, not internal architecture.
- Cost: ~3 lines in install-hooks.sh; benefit: preserves silent compatibility
  for an unbounded set of out-of-repo bash callers.

**Implementation note:** install-hooks.sh creates the symlink AFTER batch-5
deletes the canonical secrets.py from isaac/services/, in this order:

1. `pip install -e ~/ai/claude-isaac/security/node-vault-mcp` (vault_secrets
   importable system-wide)
2. `rm -f ~/ai/claude-isaac/services/secrets.py` (clean break in repo)
3. `ln -sfn ~/ai/claude-isaac/security/node-vault-mcp/services/secrets.py
   ~/ai/claude-isaac/services/secrets.py` (compatibility shim restored)
4. Same pair for `get-secret.sh`

The symlink lives outside git (`isaac/services/` would otherwise show two
copies of secrets.py); add `services/secrets.py` and `services/get-secret.sh`
to `.gitignore` if not already covered by existing rules.

## Operator Amendments (Post-Approval, Mid-Execution)

These adjustments to the decouple plan (`prepare-a-plan-that-abundant-kettle`) are operator-directed amendments folded in mid-execution after batches 1-3 completed. They extend already-approved categories (consumer migration, doc updates, install-hooks bootstrap) without changing architectural intent. The plan body's APPROVED SHA is intentionally NOT resealed — these amendments live here in a non-gated artifact, with execution fidelity tracked in the open-items table below.

### A1 — Bash-CLI compatibility symlink (batch-5 / Step 4)

Documented in detail in the **Bash-CLI Compatibility Symlink (Operator-Directed Exception)** section above. Owned by `services/install-hooks.sh`. Sweep result: 4 references in `~/.zshrc` (`ATLASSIAN_API_TOKEN`, `JIRA_API_TOKEN`, `CONFLUENCE_API_TOKEN`, `BLUETRIANGLE_API_KEY`); 0 LaunchAgent / cron / external-Python references.

### A2 — Strip stale MCP-FIRST mapping rows from `services/isaac-db.py` (batch-4 / Step 3)

Extends the existing batch-4 consumer-matrix entry for `services/isaac-db.py`. After the 8 `vault_*` tools and 8 `/api/vault/*` routes are deleted from isaac-mcp, the namespace-mapping table at `services/isaac-db.py:1593-1604` retains stale rows that would produce persistent DRIFT in `sync_doc_parity` (R1 set-membership: `vault_*` listed in mapping table but absent from `tools_set`).

| File | Lines | Action |
|------|-------|--------|
| `~/ai/claude-isaac/services/isaac-db.py` | 1593 | DELETE row `(r"^vault_", ["/api/vault/"])` |
| `~/ai/claude-isaac/services/isaac-db.py` | 1604 | DELETE / UPDATE row covering `["/api/preferences"]` (PUT route is also being deleted) |

### A3 — Update vault-access guidance in `services/isaac_server/prompts.py` (batch-6 / Step 5)

Extends batch-6's doc-updates list. The plan body's Step 5 enumerated `rules/*` and `docs/*` doc surfaces but missed `services/isaac_server/prompts.py` — an MCP prompt module visible to LLM agents.

| File | Line | Change |
|------|------|--------|
| `~/ai/claude-isaac/services/isaac_server/prompts.py` | 111 | Update guidance string `<your-workspace>/isaac/services/secrets.py get <service>` → `<your-workspace>/isaac/security/node-vault-mcp/services/secrets.py get <service>` |

## Open Items

| ID | Owner | Batch | Description |
|----|-------|-------|-------------|
| OQ-secrets-key-env | node-vault-mcp | (post-plan) | `secrets-key-env-structural-gating` proposal — gate the `SECRETS_KEY` env-override path post-extract |
| OQ-bash-cli-symlink | install-hooks.sh | batch-5 | Symlink at `isaac/services/secrets.py` + `get-secret.sh` for external bash callers (operator-approved exception per Amendment A1) |
| OQ-isaac-db-mapping-table | isaac-db.py:1593 | batch-4 | Strip stale `vault_*` / `/api/vault/` and `/api/preferences` mapping rows from MCP-FIRST namespace table (per Amendment A2) |
| OQ-prompts-py-vault-path | isaac_server/prompts.py:111 | batch-6 | Update vault-access guidance string to new node-vault-mcp path (per Amendment A3) |
| OQ-gitignore-symlink-paths | isaac/.gitignore | batch-5 | Ensure `services/secrets.py` and `services/get-secret.sh` are git-ignored after canonical deletion so the install-hooks-managed symlinks don't appear as tracked files |
